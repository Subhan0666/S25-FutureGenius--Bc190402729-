<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Instructor Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
  <div class="d-flex">
    <!-- Sidebar -->
    <div class="bg-primary text-white p-3" style="width:250px; min-height:100vh;">
      <h4>Instructor</h4>
      <ul class="nav flex-column mt-4">
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-upload"></i> Upload Course</a></li>
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-users"></i> My Students</a></li>
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-chart-line"></i> Progress Reports</a></li>
            <!-- Logout Button at bottom -->
      <a href="logout.php" class="btn btn-danger mt-auto w-100"><i class="fa fa-sign-out-alt"></i> Logout</a>
      </ul>
    </div>

    <!-- Content -->
    <div class="p-4 flex-grow-1">
      <h2>Welcome, Instructor!</h2>
      <div class="card mt-3 p-3">
        <h5>Upload New Course</h5>
        <form>
          <div class="mb-3"><input type="text" class="form-control" placeholder="Course Title"></div>
          <div class="mb-3">
            <select class="form-control">
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
          </div>
          <div class="mb-3"><textarea class="form-control" placeholder="Course Description"></textarea></div>
          <button class="btn btn-success">Upload</button>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
