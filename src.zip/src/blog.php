<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Blog - Kidicode LMS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <?php include('navbar.php') ?>
  <div class="container py-5">
    <h2 class="text-center mb-4">Kidicode Blog</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card">
          <img src="img/blog1.jpg" class="card-img-top" alt="">
          <div class="card-body">
            <h5 class="card-title">Success Story: Ali Builds a Game at Age 10</h5>
            <p>Ali created his first video game using Python...</p>
            <a href="#" class="btn btn-outline-primary">Read More</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="img/blog2.jpg" class="card-img-top" alt="">
          <div class="card-body">
            <h5 class="card-title">STEM Camp Highlights</h5>
            <p>Kids explored robotics, AI and teamwork...</p>
            <a href="#" class="btn btn-outline-primary">Read More</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="img/blog3.jpg" class="card-img-top" alt="">
          <div class="card-body">
            <h5 class="card-title">Why Kids Should Learn AI</h5>
            <p>AI is the future, and kids should be prepared...</p>
            <a href="#" class="btn btn-outline-primary">Read More</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
