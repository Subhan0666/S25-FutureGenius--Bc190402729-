<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Kidicode LMS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
  <!-- Navbar Include -->
  <?php include 'navbar.php'; ?>

  <!-- Courses Section -->
<div class="container py-5">
  <h2 class="mb-4 text-center">Available Courses</h2>
  <div class="row g-4">

    <!-- Course Card 1 -->
    <div class="col-md-4">
      <div class="card shadow-lg h-100">
        <img src="scr.jpg" class="card-img-top" alt="Course 1">
        <div class="card-body">
          <h5 class="card-title">Scratch Programming</h5>
          <p class="card-text">Learn programming concepts using Scratch in a fun and visual way.</p>
          <span class="badge bg-success">Beginner</span>
        </div>
        <div class="card-footer text-center">
          <a href="#" class="btn btn-primary btn-sm">Enroll</a>
        </div>
      </div>
    </div>

    <!-- Course Card 2 -->
    <div class="col-md-4">
      <div class="card shadow-lg h-100">
        <img src="python.jpg" class="card-img-top" alt="Course 2">
        <div class="card-body">
          <h5 class="card-title">Python Basics</h5>
          <p class="card-text">Start coding with Python and understand the basics of logic & syntax.</p>
          <span class="badge bg-warning text-dark">Intermediate</span>
        </div>
        <div class="card-footer text-center">
          <a href="#" class="btn btn-primary btn-sm">Enroll</a>
        </div>
      </div>
    </div>

    <!-- Course Card 3 -->
    <div class="col-md-4">
      <div class="card shadow-lg h-100">
        <img src="web.jpg" class="card-img-top" alt="Course 3">
        <div class="card-body">
          <h5 class="card-title">Web Development</h5>
          <p class="card-text">Learn HTML, CSS, and JavaScript to build real websites.</p>
          <span class="badge bg-danger">Advanced</span>
        </div>
        <div class="card-footer text-center">
          <a href="#" class="btn btn-primary btn-sm">Enroll</a>
        </div>
      </div>
    </div>

  </div>
</div>

 

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
