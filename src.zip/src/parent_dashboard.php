<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Parent Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
  <div class="d-flex">
    <!-- Sidebar -->
    <div class="bg-success text-white p-3" style="width:250px; min-height:100vh;">
      <h4>Parent</h4>
      <ul class="nav flex-column mt-4">
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-child"></i> Child Progress</a></li>
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-certificate"></i> Achievements</a></li>
            <!-- Logout Button at bottom -->
      <a href="logout.php" class="btn btn-danger mt-auto w-100"><i class="fa fa-sign-out-alt"></i> Logout</a>
      </ul>
    </div>

    <!-- Content -->
    <div class="p-4 flex-grow-1">
      <h2>Welcome, Parent!</h2>
      <div class="card mt-3 p-3">
        <h5>Child’s Progress</h5>
        <p><strong>Ali Ahmed</strong> - Beginner Coding</p>
        <div class="progress mb-2"><div class="progress-bar" style="width:65%">65%</div></div>
        <p><strong>Fatima Ahmed</strong> - Game Development</p>
        <div class="progress"><div class="progress-bar bg-warning" style="width:40%">40%</div></div>
      </div>
    </div>
  </div>
</body>
</html>
