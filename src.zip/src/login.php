<?php
session_start();
include "db.php";
include "navbar.php";
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $user = $res->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;

            // Redirect based on role
            if ($user['role'] == "admin") {
                header("Location: admin_dashboard.php");
            } elseif ($user['role'] == "instructor") {
                header("Location: instructor_dashboard.php");
            } elseif ($user['role'] == "student") {
                header("Location: student_dashboard.php");
            } else {
                header("Location: parent_dashboard.php");
            }
            exit;
        } else {
            $msg = "Invalid password!";
        }
    } else {
        $msg = "No user found with this email!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - Kidicode LMS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background:#f4f6f9;">
<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">
  <div class="card shadow p-4" style="width:400px;">
    <h3 class="text-center">Login</h3>
    <?php if($msg) echo "<div class='alert alert-danger'>$msg</div>"; ?>
    <form method="post">
      <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-success w-100">Login</button>
    </form>
    <p class="text-center mt-3">Don't have an account? <a href="signup.php">Sign Up</a></p>
  </div>
</div>
</body>
</html>
