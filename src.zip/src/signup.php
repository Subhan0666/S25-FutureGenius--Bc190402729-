<?php
include "db.php";
include "navbar.php";
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role  = $_POST['role'];

    $check = $conn->prepare("SELECT * FROM users WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $msg = "Email already exists!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password, $role);
        if ($stmt->execute()) {
            $msg = "Registration successful! <a href='login.php'>Login here</a>";
        } else {
            $msg = "Error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Signup - Kidicode LMS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background:#f4f6f9;">
<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">
  <div class="card shadow p-4" style="width:400px;">
    <h3 class="text-center">Create Account</h3>
    <?php if($msg) echo "<div class='alert alert-info'>$msg</div>"; ?>
    <form method="post">
      <div class="mb-3">
        <label>Name</label>
        <input type="text" name="name" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Role</label>
        <select name="role" class="form-select" required>
          <option value="admin">Admin</option>
          <option value="instructor">Instructor</option>
          <option value="student">Student</option>
          <option value="parent">Parent</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary w-100">Sign Up</button>
    </form>
    <p class="text-center mt-3">Already have an account? <a href="login.php">Login</a></p>
  </div>
</div>
</body>
</html>
