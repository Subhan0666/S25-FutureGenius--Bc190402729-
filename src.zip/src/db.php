<?php
$host = "localhost";
$user = "root";   // apna MySQL user
$pass = "";       // apna MySQL password
$db   = "kidicode_lms";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
