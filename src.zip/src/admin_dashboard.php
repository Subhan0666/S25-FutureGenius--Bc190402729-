<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
  <div class="d-flex">
    <!-- Sidebar -->
    <div class="bg-dark text-white p-3 d-flex flex-column" style="width:250px; min-height:100vh;">
      <h4 class="mb-4"><i class="fa fa-user-shield"></i> Admin Panel</h4>
      <ul class="nav flex-column flex-grow-1">
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-users"></i> Manage Users</a></li>
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-book"></i> Manage Courses</a></li>
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-chart-bar"></i> Analytics</a></li>
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-file-alt"></i> Reports</a></li>
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-comments"></i> Feedback</a></li>
        <li class="nav-item"><a href="#" class="nav-link text-white"><i class="fa fa-cogs"></i> Settings</a></li>
      </ul>
      <!-- Logout Button at bottom -->
      <a href="logout.php" class="btn btn-danger mt-auto w-100"><i class="fa fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- Content -->
    <div class="p-4 flex-grow-1">
      <h2>Welcome, Admin!</h2>
      <div class="row g-4 mt-3">
        <div class="col-md-4">
          <div class="card p-3 text-center shadow-sm">
            <h5>Total Users</h5>
            <h2>120</h2>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card p-3 text-center shadow-sm">
            <h5>Total Courses</h5>
            <h2>15</h2>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card p-3 text-center shadow-sm">
            <h5>Active Students</h5>
            <h2>80</h2>
          </div>
        </div>
      </div>

      <!-- User Management Table -->
      <div class="card mt-4 p-3 shadow-sm">
        <h5>User Management</h5>
        <table class="table table-striped">
          <thead class="table-dark">
            <tr><th>ID</th><th>Name</th><th>Role</th><th>Action</th></tr>
          </thead>
          <tbody>
            <tr><td>1</td><td>Ali</td><td>Student</td>
              <td>
                <button class="btn btn-sm btn-warning"><i class="fa fa-edit"></i> Edit</button>
                <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> Delete</button>
              </td>
            </tr>
            <tr><td>2</td><td>Fatima</td><td>Instructor</td>
              <td>
                <button class="btn btn-sm btn-warning"><i class="fa fa-edit"></i> Edit</button>
                <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
